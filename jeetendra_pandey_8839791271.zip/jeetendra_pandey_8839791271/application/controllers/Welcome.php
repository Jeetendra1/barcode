<?php

// Jeetendra Pandey(8839791271)

defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    public function index() {
        $this->load->library('ciqrcode'); //meload library barcode
        $this->load->helper('url'); //meload helper url
        $barcode_create = "jeetendra_pandey"; // write bar code whatever you want
        //settingang  barcode 

        $params['data'] = $barcode_create;
        $params['level'] = 'H';
        $params['size'] = 5;

        //settings to create a barcode file in .png format and saved in the assets folder

        $params['savename'] = FCPATH . "assets/" . $barcode_create . ".png";

        //start generating barcode

        $this->ciqrcode->generate($params);

        //try removing the barcode value that was just generated

        echo '<img src="' . base_url() . 'assets/' . $barcode_create . '.png" />';
    }

}
