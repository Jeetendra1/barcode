<?php 
class Mahasiswa extends CI_Controller{
    
	function __construct(){
		parent::__construct();
		$this->load->model('mahasiswa_model');  // loading model
	}

	function index(){
		$data['data']=$this->mahasiswa_model->get_all_mahasiswa();
		$this->load->view('mahasiswa_view',$data);
	}

	function simpan(){
            
            
		$nim=$this->input->post('nim');
		$nama=$this->input->post('nama');
		$prodi=$this->input->post('prodi');

		$this->load->library('ciqrcode'); //QR CODE library call

		$config['cacheable']	= true; //boolean, the default is true
		$config['cachedir']		= './assets/'; //string, the default is application/cache/
		$config['errorlog']		= './assets/'; //string, the default is application/logs/
		$config['imagedir']		= './assets/images/'; //qr code storage directory
		$config['quality']		= true; //boolean, the default is true
		$config['size']			= '1024'; //interger, the default is 1024
		$config['black']		= array(224,255,255); // array, default is array(255,255,255)
		$config['white']		= array(70,130,180); // array, default is array(0,0,0)
		$this->ciqrcode->initialize($config);

		$image_name='12345'.'.png'; //create a name from qr code according to nim

		$params['data'] = '12345'; //the data that will be set up QR CODE
		$params['level'] = 'H'; //H=High
		$params['size'] = 10;
		$params['savename'] = FCPATH.$config['imagedir'].$image_name; //save QR CODE image to asset / images /
		$this->ciqrcode->generate($params); // function to generate QR CODE

		$this->mahasiswa_model->simpan_mahasiswa($nim,$nama,$prodi,$image_name); //save to database
		redirect('mahasiswa'); //redirect to students after data retention
	}
}